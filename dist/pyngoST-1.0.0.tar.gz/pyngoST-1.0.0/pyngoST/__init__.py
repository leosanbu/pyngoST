# pyngoST: multiple sequence typing of Neisseria gonorrhoeae large assembly collections
# Script by Leonor Sanchez-Buso (FISABIO-Public Health, Valencia, Spain)
# Date: 10/05/2023

__version__ = "1.0.0"
